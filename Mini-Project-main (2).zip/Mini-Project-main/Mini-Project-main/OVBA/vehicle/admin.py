from django.contrib import admin
from .models import *

admin.site.register(register)
admin.site.register(shopdetails)
admin.site.register(Booking)
admin.site.register(worker)
admin.site.register(Certificate)
admin.site.register(service)
admin.site.register(complaint)
admin.site.register(complaintwoker)

